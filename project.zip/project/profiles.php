<?php 
session_start()
?>

<?php include 'dbcon.php';


$query="select * from profiles where email='{$_SESSION['email']}'";

   $result= mysqli_query($con, $query);
   
  
?>


<!DOCTYPE html>
<html>
<head>
	<title>Your profile</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
	<?php
while($rows=mysqli_fetch_assoc($result))
	{ $_SESSION['Mobile'] = $rows['Mobile'];
{$_SESSION['Education'] = $rows['Education'];
{$_SESSION['Roll_no'] = $rows['Roll_no'];
{$_SESSION['Project'] = $rows['Project'];
{$_SESSION['Name'] = $rows['Name'];
{$_SESSION['Email'] = $rows['Email'];

{$_SESSION['stream']=$rows['stream'];
{$_SESSION['image']=$rows['image'];
}


}
}
}
}
}
}

}
	
{
?>
<div class="container d-flex justify-content-center mt-5">
<div class="col-md-6 border shadow">

<ul class="nav nav-pills nav-justified">
<li class="nav-item"><a href="#profile-tab" class="nav-link active" data-toggle="pill">Profile</a></li>
<li class="nav-item"><a href="#setting-tab" class="nav-link" data-toggle="pill">Info</a></li>
<li class="nav-item"><a href="#contact-tab" class="nav-link" data-toggle="pill">Contact us</a></li>
<li class="nav-item"><a href="#help-tab" class="nav-link" data-toggle="pill">Help</a></li>
	
</ul>

  <!-- All Tabs Main div -->
	
	<div class="tab-content">

	<!-- Profile tab start -->
	
   <div class="tab-pane show fade 	active justify-content-center px-5" id="profile-tab">
   <img src="<?php echo $_SESSION['image']; ?>" width="150px" height="150px" class="rounded-circle border border-primary mx-auto d-flex my-2">
   <h2 class="text-center my-3">Your Profile</h2>
   <div class="mx-auto my-3 d-flex justify-content-center">
   	<a class="btn btn-success btn-sm" href="indexm.php">Home<i class="fas fa-user"></i>
   	</a>
   	<a class="btn btn-info mx-3 btn-sm" href="logout.php">Log out</a>
   	<a class="btn btn-info btn-sm" href="deletepros.php">Delete</a>
   
   </div>

<hr>

	
<h4>Information</h4>

<div class="float-right" style="margin-left: -200%; margin-right: 5%; ">
	<h6><i class="fas fa-university"></i>Education:-</h6>
	<p><?php echo $_SESSION['Education']; ?></p>
</div>
<div class="form-group">
	<h6><i class="fas fa-hospital-alt"></i>Project:-</h6>
	<p><?php echo $_SESSION['Project']; ?></p>

<div class="form-group">
<h6><i class="fas fa-code-branch"></i>Branch:-</h6>
	<p><?php echo $_SESSION['stream']; ?></p>
</div>
<div class="float-right" style="margin-top: -15%; margin-right: 9%">
<h6><i class="fas fa-briefcase"></i>Roll-no:-</h6>
	<p><?php echo $_SESSION['Roll_no']; ?></p>
</div>

</div>


   </div>








       <!-- Setting tab start -->

<div class="tab-pane fade p-5" id="setting-tab">


 <h4 class="text-center">Your Info </h4>
	<h6>Name:- </h6>

	<p><?php echo $_SESSION['Name']; ?><a href="#" class="float-right"></a></p>


	<h6>Email:- </h6>
	<p><?php echo $_SESSION['Email']; ?><a href="#" class="float-right"></a></p>
	
	<h6>Phone:- </h6>
	<p><?php echo $_SESSION['Mobile']; ?><a href="#" class="float-right"></a></p>
	
			
</div>

<?php
}
?> 


        <!-- Contact us tab start -->


<div class="tab-pane fade px-5 my-4" id="contact-tab">
<h3 class="text-center"></h3>
<form class="w-75 mx-auto">
	<div class="col-md-12 my-4">
		
	</div>
	<div class="col-md-12">
		
	</div>
	<div class="col-md-12">
	</div>
	<div class="col-12">
		

 <a href="indexm.php" name="button" type="button" class="btn btn-primary btn-sm form-control my-3">Contact</a>

</button>
	</div>

</form></form>
	
</div>
  
  <!-- Help tab start -->

<div class="tab-pane" id="help-tab">
	<h5 class="text-justify p-4">

<a href="fogpass.php" name="button" type="button" class="btn btn-primary btn-sm form-control my-3">Forgot-passowrd</a>

</button>
</h5>
	
</div>





	</div>

</div>
</div>



</body>
</html>