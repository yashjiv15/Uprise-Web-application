 <!DOCTYPE html>
<html>
<head>
<title></title> 
</head> 
<body>
 <li class="nav-item dropdown yamm-fw">
                     <a href="#" data-toggle="dropdown" class="dropdown-toggle nav-link">
                        Centres
                     </a>
                     <ul class="dropdown-menu dropdown-menu1">
                        <div class="explore-btn explore-btn-3">
                           <a href="centers">Explore <b>All Centres</b><span class="arrow"><span></span></span></a>
                        </div>
                        <li>
                           <a href="#" class="dropdown-item">Analytics & Data Science</a>
                        </li>
                        <li>
                           <a href="#" class="dropdown-item">Jasani Centre for Social Entrepreneurship & Sustainability <br>Management</a>
                        </li>
                        <li>
                           <a href="#" class="dropdown-item">Centre for Executive Education</a>
                        </li>
                        <li>
                           <a href="#" class="dropdown-item">Atal Incubation Centre (AIC)</a>
                        </li>
                        <li>
                           <a href="#" class="dropdown-item">Centre of Interior Environment and Design</a>
                        </li>
                     </ul>
                     </li> 

                     </header>
</body>
</html>
